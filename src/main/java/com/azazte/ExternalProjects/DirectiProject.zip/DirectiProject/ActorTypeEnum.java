package com.azazte.ExternalProjects.DirectiProject;

/**
 * Created by home on 12/01/17.
 */
public enum ActorTypeEnum {
    KING,
    QUEEN,
    KNIGHT,
    BISHOP,
    ROOK,
    PAWN
}

