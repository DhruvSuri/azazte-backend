package com.azazte.ExternalProjects.DirectiProject;

/**
 * Created by home on 12/01/17.
 */
public class ChessGame {
    private GameActor chessBoard[][];

    public ChessGame() {
    }

    public GameActor[][] initialize() {

        Player player1 = new Player();
        Player player2 = new Player();

        initializeBoard();
        initializeActors();
        return chessBoard;
    }


    public MoveResponse makeMove(int x1, int y1, int x2, int y2) {
        MoveResponse moveResponse = null;
        if (chessBoard[x1][y1] == null) {
            moveResponse = new MoveResponse();
            moveResponse.setValidMove(false);
            moveResponse.setSourceEmpty(true);
            return moveResponse;
        }

        // Xs and Ys should be in board range

        if (GameActor.isValidMove(chessBoard[x1][y1].getActorType(), this.chessBoard, x1, y1, x2, y2)) {
            // Is player on destination
            // mate check
            // victory check

        }
        return moveResponse;
    }


    private void initializeBoard() {
        this.chessBoard = new GameActor[8][8];
    }


    private void initializeActors() {

        this.chessBoard[0][0] = new GameActor(ActorTypeEnum.ROOK, 1);
        this.chessBoard[0][1] = new GameActor(ActorTypeEnum.KNIGHT, 1);
        this.chessBoard[0][2] = new GameActor(ActorTypeEnum.BISHOP, 1);
        this.chessBoard[0][3] = new GameActor(ActorTypeEnum.QUEEN, 1);
        this.chessBoard[0][4] = new GameActor(ActorTypeEnum.KING, 1);
        this.chessBoard[0][5] = new GameActor(ActorTypeEnum.BISHOP, 1);
        this.chessBoard[0][6] = new GameActor(ActorTypeEnum.KNIGHT, 1);
        this.chessBoard[0][7] = new GameActor(ActorTypeEnum.ROOK, 1);

        this.chessBoard[7][0] = new GameActor(ActorTypeEnum.ROOK, 2);
        this.chessBoard[7][1] = new GameActor(ActorTypeEnum.KNIGHT, 2);
        this.chessBoard[7][2] = new GameActor(ActorTypeEnum.BISHOP, 2);
        this.chessBoard[7][3] = new GameActor(ActorTypeEnum.QUEEN, 2);
        this.chessBoard[7][4] = new GameActor(ActorTypeEnum.KING, 2);
        this.chessBoard[7][5] = new GameActor(ActorTypeEnum.BISHOP, 2);
        this.chessBoard[7][6] = new GameActor(ActorTypeEnum.KNIGHT, 2);
        this.chessBoard[7][7] = new GameActor(ActorTypeEnum.ROOK, 2);

        assignPawns(1, 1);
        assignPawns(2, 6);
    }

    private void assignPawns(int playerNumber, int rowNumber) {
        int i = 0;
        while (i < 8) {
            this.chessBoard[rowNumber][i] = new GameActor(ActorTypeEnum.PAWN, playerNumber);
            i++;
        }
    }


}
