package com.azazte.ExternalProjects.DirectiProject;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;

/**
 * Created by home on 12/01/17.
 */
public class ChessGameClient {


    @POST
    @Path("makeMove")
    public MoveResponseWrapper makeMove(@QueryParam("x1") int x1,@QueryParam("y1") int y1,@QueryParam("x2") int x2,@QueryParam("y2") int y2){
        MoveResponseWrapper wrapper = wrapMoveResponse(game.makeMove(0, 1, 7, 2));

    }

    private static MoveResponseWrapper wrapMoveResponse(MoveResponse moveResponse) {
        return null;
        //Adapt
    }
}
