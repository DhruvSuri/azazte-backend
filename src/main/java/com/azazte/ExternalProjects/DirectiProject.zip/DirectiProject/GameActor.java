package com.azazte.ExternalProjects.DirectiProject;

/**
 * Created by home on 12/01/17.
 */
public class GameActor {

    private ActorTypeEnum actorType;
    private int playerType;
    private Boolean isAlive;

    public GameActor(ActorTypeEnum actorType, int playerType) {
        this.actorType = actorType;
        this.playerType = playerType;
    }

    public void killActor() {
        this.isAlive = false;
    }

    public static Boolean isValidMove(ActorTypeEnum actorType, GameActor[][] chessBoard, int x1, int y1, int x2, int y2) {
        switch (actorType) {
            case KING:
                // Define the moves
                // valid king move check
                break;
            case QUEEN:
                Boolean pathClear = isPathClear(chessBoard, x1, y1, x2, y2);
                isValidBishopMove();
                isValidRookMove();

                break;
            case KNIGHT:

                break;
            case BISHOP:

                // Moves Through diagnals
                Boolean pathClear = isPathClear(chessBoard, x1, y1, x2, y2);
                break;
            case ROOK:
                Boolean pathClear = isPathClear(chessBoard, x1, y1, x2, y2);
                break;
            case PAWN:

                break;
        }
        return false;
    }

    public static Boolean isPathClear(GameActor[][] chessBoard, int x1, int y1, int x2, int y2) {
        //
        if (x1 == x2) {
            // Horizontal line check
            int start;
            int end;
            if(y1 < y2){
                start = y1;
                end = y2;
            }else{
                start = y2;
                end = y1;
            }


            while (i < y2){
                if(chessBoard[x1][i] != null){
                    return false;
                }
                i++;
            }
        } else if (y1 == y2) {

        } else {

        }

    }

    public ActorTypeEnum getActorType() {
        return actorType;
    }

    public void setActorType(ActorTypeEnum actorType) {
        this.actorType = actorType;
    }

    public int getPlayerType() {
        return playerType;
    }

    public void setPlayerType(int playerType) {
        this.playerType = playerType;
    }

    public Boolean getAlive() {
        return isAlive;
    }

    public void setAlive(Boolean alive) {
        isAlive = alive;
    }
}
