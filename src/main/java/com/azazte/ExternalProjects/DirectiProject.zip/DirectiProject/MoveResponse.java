package com.azazte.ExternalProjects.DirectiProject;

/**
 * Created by home on 12/01/17.
 */
public class MoveResponse {
    GameActor takenActor;
    Boolean isValidMove;
    Boolean isMate;
    Boolean isVictory;
    Boolean sourceEmpty;
    private String reason;

    public Boolean getSourceEmpty() {
        return sourceEmpty;
    }

    public void setSourceEmpty(Boolean sourceEmpty) {
        this.sourceEmpty = sourceEmpty;
    }

    public GameActor getTakenActor() {
        return takenActor;
    }

    public void setTakenActor(GameActor takenActor) {
        this.takenActor = takenActor;
    }

    public Boolean getValidMove() {
        return isValidMove;
    }

    public void setValidMove(Boolean validMove) {
        isValidMove = validMove;
    }

    public Boolean getMate() {
        return isMate;
    }

    public void setMate(Boolean mate) {
        isMate = mate;
    }

    public Boolean getVictory() {
        return isVictory;
    }

    public void setVictory(Boolean victory) {
        isVictory = victory;
    }
}
