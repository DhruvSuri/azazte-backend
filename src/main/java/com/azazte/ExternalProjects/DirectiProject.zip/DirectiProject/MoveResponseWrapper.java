package com.azazte.ExternalProjects.DirectiProject;

/**
 * Created by home on 12/01/17.
 */
public class MoveResponseWrapper {
    // Mapping from Move response to the outside world
    private Boolean isValidMove;
    private String reasonForInvalidMove;
    private String takenPc;  // ActorTypeEnum.KING.toString();
    private Boolean isMate;
    private Boolean isVictory;
    private int playerNo;

}

