package com.azazte.ExternalProjects.DirectiProject;

/**
 * Created by home on 12/01/17.
 */
public class Player {
    private String playerName;
    private String playerAge;
    private String playerExperience;
    // Other personal information








    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public String getPlayerAge() {
        return playerAge;
    }

    public void setPlayerAge(String playerAge) {
        this.playerAge = playerAge;
    }

    public String getPlayerExperience() {
        return playerExperience;
    }

    public void setPlayerExperience(String playerExperience) {
        this.playerExperience = playerExperience;
    }


}
